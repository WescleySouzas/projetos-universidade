#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// a
void preencher(int *v, int tam){
    srand(time(NULL));
    for(int i = 0; i <= tam; i++){
        v[i] = -35 + (rand()%78);
    }
}
// b
void exibir(int *v, int tam){
    for(int i = 0; i < tam; i++){
        printf("%d ", v[i]);
    }
}
// c
int qtde_imp(int *vet, int tam){
    int cont = 0;
    for(int i = 0; i < tam; i++){
        if(vet[i] % 2 != 0){
            cont++;
        }
    }
    return cont;
}
// d
int indice_menor(int vet[], int tam){
    int menor = 100;
    for(int i = 0; i < tam; i ++){
        if(vet[i] < menor){
            // menor = vet[i]; retorna o menor numero
            menor = i;
        }
    }
    return menor;
}

/*int indice_maior(int vet[], int tam){
    int maior = -35;
    for(int i = 0; i < tam; i ++){
        if(vet[i] > maior){
             maior = vet[i]; //retorna o maior numero
            //maior = i;
        }
    }
    return maior;
}*/




int main(){
    int v[25];
    preencher(v, 25);
    exibir(v, sizeof(v)/sizeof(int));
    printf("\nO total de numeros impares eh: %d\n", qtde_imp(v, sizeof(v)/sizeof(int)));
    printf("O indice do menor do menor numero eh: %d\n", indice_menor(v, sizeof(v)/sizeof(int)));



}   
