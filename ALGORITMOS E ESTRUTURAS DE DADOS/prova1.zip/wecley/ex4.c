#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//2 pi r
//a
typedef struct {
    float x, y;
    float raio;
}circ;
//c
float perimetro(circ c){
    float peri = (2*3.14)*c.raio;
    return peri;
}
//b
void exibir(circ c){
    printf("(%.2f, %.2f) :: %.2f  => perimetro: %.2f\n", c.x, c.y, c.raio, perimetro(c));
}

//d
void mover(circ *c, float dx, float dy){

    c->x = c->x + dx;
    c->y = c->y + dy;

}

int main(){
    srand(time(NULL));

    circ c1;
    circ c2;
    
    c1.x = -20 + rand()%40;
    c1.y = -20 + rand()%40;
    c1.raio = 1 + rand()%5;

    c2.x = -20 + rand()%40;
    c2.y = -20 + rand()%40;
    c2.raio = 1 + rand()%5;

    exibir(c1);
    exibir(c2);

    mover(&c1, 2, 2);
    mover(&c2, 1, 1);

    exibir(c1);
    exibir(c2);
}