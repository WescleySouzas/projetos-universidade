#include <stdio.h>

int contar_caracteres(char *str){
    int i = 0, count = 0;
    while(str[i] != '\0'){
        if(str[i] < 'A' || str[i] > 'Z' && str[i] < 'a' || str[i] > 'z'){
            count++;
        }
        i++;
    }
        
    return count;
}

int main(){
    char str[] = "Testando 123... Funcionou!";
    printf("\nnumeros de caracter: %d", contar_caracteres(str));
   
   
    /* char mensagem[120];
    scanf("%s",&mensagem[120]);
    */
    
}