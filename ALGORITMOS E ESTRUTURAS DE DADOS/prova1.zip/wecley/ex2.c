#include <stdio.h>

int main(){
    int n = 5;

    for(int i = 5; i >= 0; i--){
        for(int j = 0; j == i - n - 1; j++){
            printf(" ");
        }
        for(int k = 0; k <= i; k++){
            printf("*");
        }
        printf("\n");
    }
}